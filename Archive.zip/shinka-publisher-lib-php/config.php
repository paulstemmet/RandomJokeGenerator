<?php 
define('TIMEOUT',10);
define('IS_RESIZE_IMAGES',TRUE);
define('REFERER','randomjokes');
define('TESTUSER','paulstemmet');

define('API_SERVER','http://ox-d.shinka.sh/ma/1.0/arj');
				
define('AdUnitID_320',"330030");
define('AdUnitID_216',"330030");
define('AdUnitID_168',"330030");
define('AdUnitID_120',"330030");		

?>